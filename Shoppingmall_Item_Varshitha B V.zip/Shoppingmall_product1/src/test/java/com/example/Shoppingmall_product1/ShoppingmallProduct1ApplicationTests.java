package com.example.Shoppingmall_product1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShoppingmallProduct1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
