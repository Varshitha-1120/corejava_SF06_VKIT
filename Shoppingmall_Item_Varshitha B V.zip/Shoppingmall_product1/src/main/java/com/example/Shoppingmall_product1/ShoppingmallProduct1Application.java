package com.example.Shoppingmall_product1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShoppingmallProduct1Application {

	public static void main(String[] args) {
		SpringApplication.run(ShoppingmallProduct1Application.class, args);
	}

}
